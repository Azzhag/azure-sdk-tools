Azure4node is an open source project to provide a node.js software development kit for the Windows Azure Storage services. 

Unit test instructions:

To run the existing unit tests / samples the following environment variables have to be set:

AZURE_STORAGE_ACCOUNT - The storage account name
AZURE_STORAGE_ACCESS_KEY - The storage account primary access key 

This information can be obtained from the Azure Management Portal:

- Login to the management portal in https://windows.azure.com/
- Select Hosted Service, Storage Accounts & CDN
- Select Storage Account
- Create a new Storage Account or select an existing one
- From here take:
  - The Name of the account (AZURE_STORAGE_ACCOUNT)
  - On the right side, clicking properties, and selecting view on the primary access key will reveal the Primary Access Key (AZURE_STORAGE_ACCESS_KEY).